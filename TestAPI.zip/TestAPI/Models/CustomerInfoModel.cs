﻿namespace TestAPI
{
    public class CustomerInfoModel
    {
        public int Total { get; set; }
        public List<CustomerModel> Customers { get; set; }
    }
}
